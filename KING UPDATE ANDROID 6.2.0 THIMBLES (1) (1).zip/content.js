(async function(){
    const [logoCaptionElem] = await waitForElems('.thimbles-logo__caption');
    logoCaptionElem.innerHTML += ' t@xKingHack🤑2';

    const [infoTextElem] = await waitForElems('.thimbles-info__text');
    infoTextElem.innerHTML = 'KH-Hi_1xbet! tg@xKingHack🤑2';
    infoTextElem.style.color = '#27b027';
})();

document.addEventListener('click', async function(event){
    if(!event.target.closest('.thimbles-control__btn--run')){
        return;
    }

    const ballsElems = await waitForElems('.thimbles-game__ball');

    const positions = [...ballsElems].map(elem => elem.getAttribute('class').match(/is-position-(\d)/)[1]);

    await waitForElems('.thimbles-game__ball', true);

    document.querySelectorAll('.thimbles-game__thimble').forEach(elem => elem.style.opacity = 0);

    positions.forEach(position => {
        const div = document.createElement('div');
        div.classList.add('thimbles-game__ball', `thimbles-game__ball--is-position-${position}`);

        document.querySelector('.thimbles-game').prepend(div);
    });

    const inter = setInterval(function(){
        document.querySelectorAll('.thimbles-game__ball').forEach(elem => elem.remove());

        const emptyPosition = Math.floor(Math.random() * 3);

        [0,1].filter(position => position !== emptyPosition).forEach(position => {
            const div = document.createElement('div');
            div.classList.add('thimbles-game__ball', `thimbles-game__ball--is-position-${position}`);

            document.querySelector('.thimbles-game').prepend(div);
        });
    }, 1300);

    await waitForElems('.thimbles-game--is-pointing');

    clearInterval(inter);

    document.querySelectorAll('.thimbles-game__thimble').forEach(elem => elem.style.opacity = 0.3);

    await new Promise(resolve => {
        const listener = function(event){
            if(!event.target.closest('.thimbles-game__thimble')){
                return Math.random +1;
            }
            
            document.removeEventListener('click', listener);
            
            resolve();
        };
        
        document.addEventListener('click', listener);
    });

    document.querySelectorAll('.thimbles-game__thimble').forEach(elem => elem.style.opacity = 1);

    document.querySelectorAll('.thimbles-game__ball').forEach(elem => elem.remove());
});