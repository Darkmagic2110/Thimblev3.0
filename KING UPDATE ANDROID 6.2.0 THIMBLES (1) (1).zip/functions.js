function waitForElems(selector, reversed = false){
    return new Promise(resolve => {
        let inter = setInterval(function(){
            const elems = document.querySelectorAll(selector);
            if(!!elems.length === reversed){
                return;
            }
    
            clearInterval(inter);
    
            resolve(elems);
        }, 100);
    });
}